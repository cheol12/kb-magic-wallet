package kb04.team02.web.mvc.repository.member;

import org.springframework.stereotype.Repository;

@Repository
public interface MemberRepository {
}
