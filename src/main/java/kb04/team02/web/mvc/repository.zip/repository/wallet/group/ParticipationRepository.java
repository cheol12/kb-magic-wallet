package kb04.team02.web.mvc.repository.wallet.group;

public interface ParticipationRepository {
}
