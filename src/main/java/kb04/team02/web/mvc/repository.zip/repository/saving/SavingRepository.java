package kb04.team02.web.mvc.repository.saving;

public interface SavingRepository {
}
